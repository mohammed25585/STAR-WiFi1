# سيرفر كرت شبكة

يربط بين:
- لوحة التحكم
- صفحة العميل
- جسر الرسائل (SMS Bridge)

## التشغيل المحلي

```bash
cd kart-server
npm install
npm start
```

السيرفر يشتغل على: http://localhost:3000

## رفع مجاني على Render

1. اعمل حساب على https://render.com
2. New → Web Service
3. اربط GitHub أو ارفع الملفات
4. الإعدادات:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. بعد النشر خذ الرابط مثل: `https://xxx.onrender.com`

## ربط جسر الرسائل

في تطبيق جسر الرسائل ضع:

```
رابط السيرفر: https://YOUR-SERVER.onrender.com/api/sms
```

## ربط الموقع (Netlify)

في ملف `js/config.js` أو قبل تحميل التطبيق:

```js
window.API_BASE = 'https://YOUR-SERVER.onrender.com';
```

## أهم المسارات

| Method | Path | الوصف |
|--------|------|--------|
| GET | /api/health | فحص |
| GET | /api/packages | الباقات للعميل |
| POST | /api/orders | طلب جديد من العميل |
| GET | /api/orders/:id | حالة الطلب |
| POST | /api/sms | استقبال من جسر الرسائل |
| GET | /api/admin/all | كل بيانات الإدارة |
| POST | /api/admin/manual-send | إرسال يدوي |
| POST | /api/admin/feed-cards | تغذية كروت |

