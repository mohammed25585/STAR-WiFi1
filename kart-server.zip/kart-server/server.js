const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const SMS_SECRET = process.env.SMS_SECRET || '';

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// ---------- Storage ----------
function defaultData() {
  return {
    packages: [
      { id: 1, name: 'باقة 100 جيجا', price: 120, active: true },
      { id: 2, name: 'باقة 50 جيجا', price: 70, active: true },
      { id: 3, name: 'باقة 20 جيجا', price: 35, active: true },
      { id: 4, name: 'باقة مكالمات', price: 50, active: true },
      { id: 5, name: 'باقة سوشيال', price: 40, active: true }
    ],
    cards: [],
    sales: [],
    customers: [],
    wallets: [
      { id: 1, name: 'فودافون كاش', number: '01012345678', balance: 0 },
      { id: 2, name: 'أورانج كاش', number: '01234567890', balance: 0 }
    ],
    messages: [],
    pending: [],
    offers: [],
    pos: [],
    settings: {
      storeName: 'كرت شبكة',
      phone: '773779585',
      whatsappToken: ''
    }
  };
}

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return { ...defaultData(), ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) };
    }
  } catch (e) {
    console.error('Load error', e.message);
  }
  const data = defaultData();
  // seed some cards
  for (let i = 0; i < 50; i++) {
    data.cards.push({
      id: uuidv4(),
      code: 'CARD-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
      packageId: (i % 5) + 1,
      status: 'available',
      soldAt: null,
      customer: null
    });
  }
  saveData(data);
  return data;
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

let db = loadData();

// ---------- Helpers ----------
function stats() {
  const cards = db.cards || [];
  return {
    offers: cards.filter(c => c.status === 'offer').length,
    used: cards.filter(c => c.status === 'used').length,
    available: cards.filter(c => c.status === 'available').length,
    packages: (db.packages || []).length
  };
}

function findAvailableCard(packageId) {
  return (db.cards || []).find(c => c.packageId === Number(packageId) && c.status === 'available');
}

// ---------- Public / shared API ----------
app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

app.get('/api/stats', (req, res) => {
  res.json(stats());
});

app.get('/api/packages', (req, res) => {
  const packages = (db.packages || []).filter(p => p.active !== false).map(p => {
    const available = (db.cards || []).filter(c => c.packageId === p.id && c.status === 'available').length;
    return { ...p, available };
  });
  res.json(packages);
});

app.get('/api/wallets', (req, res) => {
  res.json(db.wallets || []);
});

// Create pending order (customer page)
app.post('/api/orders', (req, res) => {
  const { packageId, phone, name, walletId } = req.body || {};
  if (!packageId || !phone) {
    return res.status(400).json({ error: 'packageId and phone required' });
  }
  const pkg = (db.packages || []).find(p => p.id === Number(packageId));
  if (!pkg) return res.status(404).json({ error: 'package not found' });
  const card = findAvailableCard(packageId);
  if (!card) return res.status(409).json({ error: 'no cards available' });

  const order = {
    id: uuidv4(),
    packageId: Number(packageId),
    packageName: pkg.name,
    price: pkg.price,
    phone: String(phone).trim(),
    name: (name || '').trim(),
    walletId: walletId || null,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  db.pending = db.pending || [];
  db.pending.push(order);
  saveData(db);
  res.json({ ok: true, order });
});

// Check order status (customer polling)
app.get('/api/orders/:id', (req, res) => {
  const pending = (db.pending || []).find(o => o.id === req.params.id);
  if (pending) return res.json({ status: 'pending', order: pending });

  const sale = (db.sales || []).find(s => s.orderId === req.params.id);
  if (sale) {
    return res.json({
      status: 'completed',
      cardCode: sale.cardCode,
      packageName: sale.packageName,
      phone: sale.phone
    });
  }
  res.status(404).json({ error: 'order not found' });
});

// ---------- SMS Bridge webhook ----------
app.post('/api/sms', (req, res) => {
  const { sender, body, amount, secret, timestamp, device } = req.body || {};

  if (SMS_SECRET && secret !== SMS_SECRET) {
    return res.status(401).json({ error: 'invalid secret' });
  }

  const msg = {
    id: uuidv4(),
    sender: sender || '',
    body: body || '',
    amount: amount ? String(amount).replace(/,/g, '') : '',
    device: device || '',
    timestamp: timestamp || Date.now(),
    matched: false,
    receivedAt: new Date().toISOString()
  };

  db.messages = db.messages || [];
  db.messages.unshift(msg);

  // Try match pending order by amount
  const amt = parseFloat(msg.amount);
  if (!isNaN(amt) && amt > 0) {
    const pending = (db.pending || []).filter(o => o.status === 'pending');
    // Prefer exact price match, oldest first
    const match = pending
      .filter(o => Number(o.price) === amt)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))[0];

    if (match) {
      const card = findAvailableCard(match.packageId);
      if (card) {
        card.status = 'used';
        card.soldAt = new Date().toISOString();
        card.customer = match.phone;

        const sale = {
          id: uuidv4(),
          orderId: match.id,
          packageId: match.packageId,
          packageName: match.packageName,
          price: match.price,
          phone: match.phone,
          name: match.name,
          cardCode: card.code,
          date: new Date().toLocaleString('ar-EG'),
          type: 'auto',
          wallet: match.walletId
        };
        db.sales = db.sales || [];
        db.sales.push(sale);

        // customer
        let cust = (db.customers || []).find(c => c.phone === match.phone);
        if (cust) {
          cust.purchases = (cust.purchases || 0) + 1;
          if (match.name) cust.name = match.name;
        } else {
          db.customers = db.customers || [];
          db.customers.push({ phone: match.phone, name: match.name || '', purchases: 1 });
        }

        db.pending = (db.pending || []).filter(o => o.id !== match.id);
        msg.matched = true;
        msg.orderId = match.id;
        msg.cardCode = card.code;

        saveData(db);
        return res.json({
          ok: true,
          matched: true,
          orderId: match.id,
          cardCode: card.code,
          phone: match.phone
        });
      }
    }
  }

  saveData(db);
  res.json({ ok: true, matched: false, messageId: msg.id });
});

// ---------- Admin APIs ----------
app.get('/api/admin/all', (req, res) => {
  res.json({
    stats: stats(),
    packages: db.packages || [],
    cards: db.cards || [],
    sales: (db.sales || []).slice().reverse(),
    customers: db.customers || [],
    wallets: db.wallets || [],
    messages: (db.messages || []).slice(0, 100),
    pending: db.pending || [],
    offers: db.offers || [],
    pos: db.pos || [],
    settings: db.settings || {}
  });
});

app.post('/api/admin/manual-send', (req, res) => {
  const { packageId, phone, name, notes } = req.body || {};
  if (!packageId || !phone) return res.status(400).json({ error: 'missing fields' });
  const pkg = (db.packages || []).find(p => p.id === Number(packageId));
  if (!pkg) return res.status(404).json({ error: 'package not found' });
  const card = findAvailableCard(packageId);
  if (!card) return res.status(409).json({ error: 'no cards available' });

  card.status = 'used';
  card.soldAt = new Date().toISOString();
  card.customer = phone;

  const sale = {
    id: uuidv4(),
    packageId: Number(packageId),
    packageName: pkg.name,
    price: pkg.price,
    phone,
    name: name || '',
    notes: notes || '',
    cardCode: card.code,
    date: new Date().toLocaleString('ar-EG'),
    type: 'manual'
  };
  db.sales = db.sales || [];
  db.sales.push(sale);

  let cust = (db.customers || []).find(c => c.phone === phone);
  if (cust) {
    cust.purchases = (cust.purchases || 0) + 1;
    if (name) cust.name = name;
  } else {
    db.customers = db.customers || [];
    db.customers.push({ phone, name: name || '', purchases: 1 });
  }
  saveData(db);
  res.json({ ok: true, cardCode: card.code, sale });
});

app.post('/api/admin/feed-cards', (req, res) => {
  const { packageId, codes } = req.body || {};
  if (!packageId || !Array.isArray(codes)) {
    return res.status(400).json({ error: 'packageId and codes[] required' });
  }
  let added = 0;
  let skipped = 0;
  db.cards = db.cards || [];
  for (const raw of codes) {
    const code = String(raw).trim();
    if (!code) continue;
    if (db.cards.some(c => c.code === code)) {
      skipped++;
      continue;
    }
    db.cards.push({
      id: uuidv4(),
      code,
      packageId: Number(packageId),
      status: 'available',
      soldAt: null,
      customer: null
    });
    added++;
  }
  saveData(db);
  res.json({ ok: true, added, skipped, stats: stats() });
});

app.post('/api/admin/packages', (req, res) => {
  const { name, price } = req.body || {};
  if (!name || price == null) return res.status(400).json({ error: 'name and price required' });
  const ids = (db.packages || []).map(p => p.id);
  const id = ids.length ? Math.max(...ids) + 1 : 1;
  db.packages = db.packages || [];
  db.packages.push({ id, name, price: Number(price), active: true });
  saveData(db);
  res.json({ ok: true, packages: db.packages });
});

app.patch('/api/admin/packages/:id', (req, res) => {
  const p = (db.packages || []).find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'not found' });
  if (typeof req.body.active === 'boolean') p.active = req.body.active;
  if (req.body.name) p.name = req.body.name;
  if (req.body.price != null) p.price = Number(req.body.price);
  saveData(db);
  res.json({ ok: true, package: p });
});

app.delete('/api/admin/packages/:id', (req, res) => {
  db.packages = (db.packages || []).filter(p => p.id !== Number(req.params.id));
  saveData(db);
  res.json({ ok: true });
});

app.post('/api/admin/customers', (req, res) => {
  const { phone, name } = req.body || {};
  if (!phone) return res.status(400).json({ error: 'phone required' });
  db.customers = db.customers || [];
  if (db.customers.some(c => c.phone === phone)) {
    return res.status(409).json({ error: 'exists' });
  }
  db.customers.push({ phone, name: name || '', purchases: 0 });
  saveData(db);
  res.json({ ok: true, customers: db.customers });
});

app.delete('/api/admin/customers/:phone', (req, res) => {
  db.customers = (db.customers || []).filter(c => c.phone !== req.params.phone);
  saveData(db);
  res.json({ ok: true });
});

app.post('/api/admin/wallets', (req, res) => {
  const { name, number } = req.body || {};
  if (!name || !number) return res.status(400).json({ error: 'name and number required' });
  const ids = (db.wallets || []).map(w => w.id);
  const id = ids.length ? Math.max(...ids) + 1 : 1;
  db.wallets = db.wallets || [];
  db.wallets.push({ id, name, number, balance: 0 });
  saveData(db);
  res.json({ ok: true, wallets: db.wallets });
});

app.delete('/api/admin/wallets/:id', (req, res) => {
  db.wallets = (db.wallets || []).filter(w => w.id !== Number(req.params.id));
  saveData(db);
  res.json({ ok: true });
});

app.get('/api/admin/cards', (req, res) => {
  const status = req.query.status;
  let cards = db.cards || [];
  if (status) cards = cards.filter(c => c.status === status);
  res.json(cards);
});

app.delete('/api/admin/cards/:id', (req, res) => {
  db.cards = (db.cards || []).filter(c => c.id !== req.params.id);
  saveData(db);
  res.json({ ok: true, stats: stats() });
});

app.put('/api/admin/settings', (req, res) => {
  db.settings = { ...(db.settings || {}), ...req.body };
  saveData(db);
  res.json({ ok: true, settings: db.settings });
});

// Serve static frontend if present (optional local test)
const frontend = path.join(__dirname, 'public');
if (fs.existsSync(frontend)) {
  app.use(express.static(frontend));
}

app.listen(PORT, () => {
  console.log(`كرت شبكة API running on port ${PORT}`);
  console.log(`SMS webhook: POST /api/sms`);
  console.log(`Health: GET /api/health`);
});
